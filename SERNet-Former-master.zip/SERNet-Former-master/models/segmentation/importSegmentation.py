import torchvision.models as models
	deeplabv3_resnet50 = models.deeplabv3_resnet50(pretrained=True)
	deeplabv3_resnet101 = models.deeplabv3_resnet101(pretrained=True)